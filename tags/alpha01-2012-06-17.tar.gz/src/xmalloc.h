/*
** xmalloc.h for  in /home/marcha_r/Dropbox/projects/42sh/home/marcha_r
** 
** Made by theo marchal
** Login   <marcha_r@epitech.net>
** 
** Started on  Fri Apr  6 20:17:06 2012 theo marchal
** Last update Wed Jun 13 16:26:49 2012 
*/

#ifndef __DUCK_IMAGE_XMALLOC__
#define __DUCK_IMAGE_XMALLOC__

#include "stdlib.h"

void	*xmalloc(unsigned int);

#endif
