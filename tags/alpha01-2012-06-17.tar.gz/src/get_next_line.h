/*
** get_next_line.h for  in /home/bruder_r//Documents/projets/unix_fonc/get_next_line
** 
** Made by romain bruder
** Login   <bruder_r@epitech.net>
** 
** Started on  Fri Nov 25 13:39:13 2011 romain bruder
** Last update Wed Jun 13 16:34:05 2012 
*/

#ifndef __GET_N_LINE__
#define __GET_N_LINE__

#define __READ__		4048
#define __SIZE_BUFF_OUT__	4048

char*	get_next_line(const int fd);

#endif
